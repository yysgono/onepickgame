const animalItems = [
  {
    id: 1,
    name: "Cute Cat",
    type: "youtube",
    youtubeId: "J---aiyznGQ"
  },
  {
    id: 2,
    name: "Funny Dog",
    type: "youtube",
    youtubeId: "tntOCGkgt98"
  }
];
export default animalItems;
