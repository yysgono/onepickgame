const foodItems = [
  {
    id: 1,
    name: "Pizza",
    type: "image",
    image: "https://images.unsplash.com/photo-1542281286-9e0a16bb7366"
  },
  {
    id: 2,
    name: "Burger",
    type: "image",
    image: "https://images.unsplash.com/photo-1550547660-d9450f859349"
  }
];
export default foodItems;

