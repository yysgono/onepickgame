import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";

// 파일 업로드 후 Storage URL 반환
export async function uploadCandidateImage(file, userId = "guest") {
  const storage = getStorage();
  const ext = file.name.split(".").pop();
  const storageRef = ref(storage, `candidates/${userId}/${Date.now()}.${ext}`);
  await uploadBytes(storageRef, file);
  return await getDownloadURL(storageRef);
}
