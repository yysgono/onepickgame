const COLORS = {
  main: "#1976ed",
  sub: "#45b7fa",
  lightGray: "#fafdff",
  darkText: "#194893",
  danger: "#d33",
  gray: "#444",
  edit: "#1976ed",
};
export default COLORS;
