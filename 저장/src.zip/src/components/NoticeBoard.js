import React, { useEffect, useState } from "react";
import { supabase } from "../utils/supabaseClient";
import { useNavigate } from "react-router-dom";

const notices = [
  { id: "notice-1", title: "Service Maintenance Notice" },
  { id: "notice-2", title: "New Features Added!" },
];

function NoticeBoard() {
  const [recentComments, setRecentComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    async function fetchRecent() {
      setLoading(true);
      const { data } = await supabase
        .from("comments")
        .select(`
          id, content, nickname, cup_id,
          worldcups ( title )
        `)
        .order("created_at", { ascending: false })
        .limit(5);

      setRecentComments((data || []).map(row => ({
        ...row,
        cupTitle: row.worldcups?.title || row.cup_id
      })));
      setLoading(false);
    }
    fetchRecent();
  }, []);

  return (
    <div style={{
      width: 700,
      maxWidth: 950,
      minWidth: 520,
      borderRadius: 22,
      background: "linear-gradient(135deg,#181e2a 80%,#1c2335 100%)",
      boxShadow: "0 6px 28px 0 #12203f77",
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-start",
      justifyContent: "flex-start",
      padding: "28px 32px 28px 32px",
      boxSizing: "border-box",
      overflow: "hidden"
    }}>
      <div style={{
        fontWeight: 900,
        fontSize: 27,
        color: "#3faaff",
        letterSpacing: "-1.2px",
        marginBottom: 14,
        width: "100%",
        lineHeight: 1.09,
      }}>
        Notice & Recent Comments
      </div>
      {/* 공지사항 */}
      <div style={{ marginBottom: 8, width: "100%" }}>
        {notices.map(notice => (
          <div
            key={notice.id}
            style={{
              fontWeight: 800,
              fontSize: 17,
              color: "#ffe081",
              lineHeight: 1.18,
              cursor: "pointer",
              marginBottom: 3,
              textOverflow: "ellipsis",
              whiteSpace: "nowrap",
              overflow: "hidden",
              width: "100%",
              padding: "2px 0 2px 2px",
              borderRadius: 5,
              transition: "background 0.12s",
            }}
            onClick={() => navigate(`/notice/${notice.id}`)}
            title="Click to see details"
          >
            <span style={{
              paddingRight: 8,
              display: "inline-block",
              maxWidth: "100%",
              verticalAlign: "middle"
            }}>📢 {notice.title}</span>
          </div>
        ))}
        <div style={{ marginTop: 2 }}>
          <span
            style={{
              color: "#5eb8ff",
              cursor: "pointer",
              fontWeight: 600,
              fontSize: 15
            }}
            onClick={() => navigate("/notice")}
          >
            + More notices
          </span>
        </div>
      </div>
      {/* 구분선 */}
      <div style={{
        width: "100%",
        height: 1,
        background: "#23355299",
        margin: "7px 0 6px 0"
      }} />
      {/* 최근 댓글 */}
      <div style={{
        width: "100%",
        fontWeight: 800,
        color: "#7ad6ff",
        fontSize: 16,
        margin: "0 0 5px 0"
      }}>
        Recent Comments
      </div>
      <div style={{
        width: "100%",
        display: "flex",
        flexDirection: "column",
        gap: 8,
        maxHeight: "none",
      }}>
        {loading ? (
          <div style={{ color: "#aaa", fontSize: 15 }}>Loading...</div>
        ) : recentComments.length === 0 ? (
          <div style={{ color: "#aaa", fontSize: 15 }}>No comments</div>
        ) : (
          recentComments.map(cmt => (
            <div
              key={cmt.id}
              style={{
                background: "#213046",
                borderRadius: 7,
                padding: "6px 10px",
                color: "#fff",
                fontSize: 16,
                fontWeight: 800,
                boxShadow: "0 1px 7px #1676ed10",
                cursor: "pointer",
                marginBottom: 1,
                display: "flex",
                alignItems: "center",
                minHeight: "auto",
                width: "100%",
                gap: 12,
                overflow: "hidden",
                whiteSpace: "nowrap",
              }}
              title={`${cmt.content} / ${cmt.nickname} / ${cmt.cupTitle}`}
              onClick={() => window.location.href = `/en/stats/${cmt.cup_id}`}
            >
              <span style={{
                color: "#fff",
                fontWeight: 900,
                marginRight: 12,
                textShadow: "0 1px 6px #0005",
                maxWidth: 220,
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
                display: "inline-block",
                verticalAlign: "middle"
              }}>
                {cmt.content}
              </span>
              <span style={{
                color: "#ffe381",
                fontWeight: 700,
                marginRight: 12,
                minWidth: 68,
                maxWidth: 90,
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
                display: "inline-block"
              }}>
                {cmt.nickname}
              </span>
              <span style={{
                color: "#a3d8ff",
                fontWeight: 500,
                flexGrow: 1,
                minWidth: 80,
                maxWidth: "100%",
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
                display: "inline-block",
                verticalAlign: "middle",
                textAlign: "left"
              }}>
                {cmt.cupTitle}
              </span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default NoticeBoard;
