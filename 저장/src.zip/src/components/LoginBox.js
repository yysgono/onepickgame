import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { supabase } from "../utils/supabaseClient";
import { useTranslation } from "react-i18next";

function LoginBox({ setUser, setNickname }) {
  const { t, i18n } = useTranslation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  async function handleLogin(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    const { data, error: loginError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    setLoading(false);
    if (loginError) {
      if (
        loginError.message.includes("Invalid login credentials") ||
        loginError.message.includes("invalid") ||
        loginError.message.includes("잘못된")
      ) {
        setError(t("login_fail_wrong_info"));
      } else {
        setError(loginError.message || t("login_failed"));
      }
      return;
    }
    if (data?.user) {
      setUser && setUser(data.user);
      const { data: profile } = await supabase
        .from("profiles")
        .select("nickname")
        .eq("id", data.user.id)
        .single();
      setNickname && setNickname(profile?.nickname || "");
    }
    setEmail("");
    setPassword("");
    navigate("/");
  }

  async function handleGoogleLogin() {
    setError("");
    const { error } = await supabase.auth.signInWithOAuth({ provider: "google" });
    if (error) {
      console.error("Google login error:", error);
      setError(t("login_failed") || "Login failed");
    }
  }

  return (
    <div
      style={{
        maxWidth: 360,
        margin: "80px auto",
        background: "#fff",
        borderRadius: 14,
        boxShadow: "0 2px 12px #0001",
        padding: 30,
      }}
      aria-label={t("login")}
    >
      <h2 style={{ textAlign: "center", marginBottom: 20 }}>{t("login")}</h2>
      <form onSubmit={handleLogin}>
        <input
          type="email"
          value={email}
          onChange={e => setEmail(e.target.value)}
          placeholder={t("email")}
          aria-label={t("email")}
          autoCapitalize="none"
          autoComplete="email"
          style={{
            width: "100%",
            padding: 10,
            borderRadius: 7,
            border: "1.2px solid #bbb",
            fontSize: 16,
            marginBottom: 12,
          }}
          required
          spellCheck={false}
        />
        <input
          type="password"
          value={password}
          onChange={e => setPassword(e.target.value)}
          placeholder={t("password")}
          aria-label={t("password")}
          autoComplete="current-password"
          style={{
            width: "100%",
            padding: 10,
            borderRadius: 7,
            border: "1.2px solid #bbb",
            fontSize: 16,
            marginBottom: 18,
          }}
          required
        />
        <button
          type="submit"
          disabled={loading}
          style={{
            width: "100%",
            background: "#1976ed",
            color: "#fff",
            fontWeight: 800,
            border: "none",
            borderRadius: 9,
            fontSize: 19,
            padding: "11px 0",
            marginBottom: 8,
            cursor: loading ? "not-allowed" : "pointer",
          }}
        >
          {loading ? t("logging_in") : t("login")}
        </button>
        {/* --- 구글 로그인 버튼 --- */}
        <button
          type="button"
          onClick={handleGoogleLogin}
          style={{
            width: "100%",
            background: "#fff",
            color: "#222",
            fontWeight: 600,
            border: "1.5px solid #ccc",
            borderRadius: 9,
            fontSize: 16,
            padding: "10px 0",
            marginBottom: 12,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 10,
          }}
        >
          <img
            src="/icons/google.svg"
            alt="Google"
            style={{
              width: 22,
              height: 22,
              verticalAlign: "middle",
              marginRight: 3,
              display: "inline-block",
            }}
            draggable={false}
            loading="lazy"
            aria-hidden="true"
          />
          {t("Google") || "Google"}
        </button>
        {error && (
          <div style={{ color: "red", marginTop: 10, textAlign: "center" }}>
            {error}
          </div>
        )}
      </form>
      <div style={{ marginTop: 14, width: "100%", textAlign: "center" }}>
        {/* 아래 3개 링크 경로 수정 (언어코드 포함!) */}
        <Link
          to={`/${i18n.language}/signup`}
          style={{ color: "#1976ed", marginBottom: 7, display: "block" }}
        >
          {t("register_as_member")}
        </Link>
        <Link
          to={`/${i18n.language}/find-id`}
          style={{ color: "#555", marginBottom: 5, display: "block" }}
        >
          {t("find_id")}
        </Link>
        <Link
          to={`/${i18n.language}/find-pw`}
          style={{ color: "#555", display: "block" }}
        >
          {t("find_pw")}
        </Link>
      </div>
    </div>
  );
}

export default LoginBox;
