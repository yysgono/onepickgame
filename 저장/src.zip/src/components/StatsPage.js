import React, { useState, useEffect } from "react";
import { fetchWinnerStatsFromDB } from "../utils";
import { useTranslation } from "react-i18next";
import MediaRenderer from "./MediaRenderer";
import { supabase } from "../utils/supabaseClient";
import CommentBox from "./CommentBox";

// 타이틀 2줄 20글자, 41자 이상 ... 처리
function twoLineTitle(title) {
  if (!title) return "";
  if (title.length <= 20) return title;
  if (title.length <= 40)
    return (
      <>
        {title.slice(0, 20)}
        <br />
        {title.slice(20)}
      </>
    );
  return (
    <>
      {title.slice(0, 20)}
      <br />
      {title.slice(20, 40) + "..."}
    </>
  );
}

// 신고 버튼
function ReportButton({ cupId, size = "md" }) {
  const [show, setShow] = useState(false);
  const [reason, setReason] = useState("");
  const [ok, setOk] = useState("");
  const [error, setError] = useState("");
  const style =
    size === "sm"
      ? {
          color: "#d33",
          background: "#fff4f4",
          border: "1.2px solid #f6c8c8",
          borderRadius: 8,
          padding: "3px 11px",
          fontSize: 15,
          fontWeight: 700,
          cursor: "pointer",
          minWidth: 50,
        }
      : {
          color: "#d33",
          background: "#fff4f4",
          border: "1.5px solid #f6c8c8",
          borderRadius: 8,
          padding: "6px 18px",
          fontSize: 17,
          fontWeight: 700,
          cursor: "pointer",
          minWidth: 60,
        };
  async function handleReport() {
    setError("");
    setOk("");
    const { data } = await supabase.auth.getUser();
    if (!data?.user?.id) return setError("로그인 필요");
    const { error } = await supabase.from("reports").insert([
      {
        type: "worldcup",
        target_id: cupId,
        reporter_id: data.user.id,
        reason,
      },
    ]);
    if (error) setError(error.message);
    else setOk("신고가 접수되었습니다. 감사합니다.");
  }
  return (
    <>
      <button onClick={() => setShow(true)} style={style}>
        🚩 신고
      </button>
      {show && (
        <div
          style={{
            position: "fixed",
            left: 0,
            top: 0,
            width: "100vw",
            height: "100vh",
            background: "#0006",
            zIndex: 9999,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <div
            style={{
              background: "#fff",
              borderRadius: 14,
              padding: 22,
              minWidth: 270,
            }}
          >
            <b>신고 사유</b>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              style={{ width: "95%", minHeight: 60, marginTop: 12 }}
              placeholder="신고 사유를 입력하세요 (선택)"
            />
            <div style={{ marginTop: 12 }}>
              <button onClick={handleReport} style={{ marginRight: 10 }}>
                신고하기
              </button>
              <button onClick={() => setShow(false)}>닫기</button>
            </div>
            {ok && <div style={{ color: "#1976ed", marginTop: 7 }}>{ok}</div>}
            {error && (
              <div style={{ color: "#d33", marginTop: 7 }}>{error}</div>
            )}
          </div>
        </div>
      )}
    </>
  );
}

// 기간 선택
const PERIODS = [
  { label: "전체", value: null },
  { label: "1개월", value: 30 },
  { label: "3개월", value: 90 },
  { label: "6개월", value: 180 },
  { label: "1년", value: 365 },
];

// 퍼센트 표시
function percent(n, d) {
  if (!d) return "-";
  return Math.round((n / d) * 100) + "%";
}
function getSinceDate(days) {
  if (!days) return null;
  const date = new Date();
  date.setDate(date.getDate() - days);
  return date.toISOString();
}
function getCustomSinceDate(from, to) {
  if (!from || !to) return null;
  const fromIso = new Date(from).toISOString();
  const toIso = new Date(to).toISOString();
  return { from: fromIso, to: toIso };
}

// 1~3위 카드
function RankCard({
  rank,
  name,
  image,
  win_count,
  win_rate,
  match_wins,
  match_count,
  match_win_rate,
  isMobile,
}) {
  const medals = [
    { emoji: "🥇", color: "#f8c800", shadow: "#ecd95d44", text: "#bb9800" },
    { emoji: "🥈", color: "#ff9700", shadow: "#faad4433", text: "#a9812e" },
    { emoji: "🥉", color: "#ef5b7b", shadow: "#f77e8b19", text: "#e26464" },
  ];
  const medal = medals[rank - 1] || medals[2];
  const bg = ["#fcf5cd", "#eef3fa", "#fff3f3"][rank - 1];
  return (
    <div
      style={{
        background: bg,
        borderRadius: 26,
        boxShadow: "0 8px 36px #1114, 0 2px 12px #eee4",
        padding: isMobile ? 19 : 32,
        minWidth: isMobile ? 210 : 270,
        maxWidth: 340,
        margin: "32px 15px 18px 15px",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        position: "relative",
        minHeight: isMobile ? 200 : 300,
        border: "2.2px solid #faf7ee",
        zIndex: 2,
      }}
    >
      {/* 큰 메달! */}
      <div
        style={{
          position: "absolute",
          left: "50%",
          top: -47,
          transform: "translateX(-50%)",
          fontSize: 56,
          fontWeight: 900,
          textShadow: `0 2px 24px ${medal.shadow}`,
          color: medal.color,
          background: "#fffde8",
          borderRadius: "50%",
          width: 70,
          height: 70,
          border: `5px solid ${medal.color}`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: 5,
        }}
      >
        {medal.emoji}
      </div>
      <div
        style={{
          width: isMobile ? 92 : 116,
          height: isMobile ? 92 : 116,
          borderRadius: "50%",
          overflow: "hidden",
          margin: "60px auto 20px auto",
          boxShadow: "0 2px 16px #8883, 0 0px 0px #fff8",
          background: "#fff",
        }}
      >
        <MediaRenderer url={image} alt={name} />
      </div>
      <div style={{ fontWeight: 800, fontSize: isMobile ? 29 : 34, margin: "0 0 8px 0", color: medal.text }}>
        {rank}
      </div>
      <div
        style={{
          fontWeight: 900,
          fontSize: isMobile ? 18 : 23,
          color: "#716500",
          marginBottom: 8,
        }}
      >
        우승 {win_count} | <span style={{ color: "#9d8703" }}>우승률 {win_rate}</span>
      </div>
      <div
        style={{
          fontSize: isMobile ? 15 : 17,
          color: "#9098a6",
          fontWeight: 600,
          letterSpacing: "-0.2px",
          marginBottom: 4,
        }}
      >
        승리 {match_wins} | 대결 {match_count} | 승률 {match_win_rate}
      </div>
    </div>
  );
}

// 통계 테이블 로딩
function StatsSkeleton({ isMobile = false }) {
  const dummyRows = Array(7).fill(0);
  return (
    <div style={{ width: "100%", overflowX: "auto" }}>
      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          background: "#fff",
          borderRadius: "12px",
          textAlign: "center",
          fontSize: isMobile ? 13 : 17,
          tableLayout: "fixed",
        }}
      >
        <thead>
          <tr style={{ background: "#f7f7f7" }}>
            {["순위", "이미지", "이름", "우승", "우승률", "승리", "대결", "승률"].map((h, i) => (
              <th key={i} style={{ padding: "10px 0" }}>
                <div
                  style={{
                    width: 60,
                    height: 18,
                    margin: "0 auto",
                    background: "#e7f1fb",
                    borderRadius: 7,
                    animation: "skeleton-loading 1.2s infinite linear",
                  }}
                />
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {dummyRows.map((_, i) => (
            <tr key={i}>
              {[...Array(8)].map((_, j) => (
                <td key={j} style={{ padding: "13px 0" }}>
                  <div
                    style={{
                      height: 18,
                      width: j === 1 ? (isMobile ? 30 : 44) : isMobile ? 38 : 70,
                      margin: "0 auto",
                      background: "#e7f1fb",
                      borderRadius: 7,
                      animation: "skeleton-loading 1.2s infinite linear",
                    }}
                  />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      <style>{`
        @keyframes skeleton-loading {
          0% { background-color: #e7f1fb; }
          50% { background-color: #e4ebf3; }
          100% { background-color: #e7f1fb; }
        }
      `}</style>
    </div>
  );
}

// ---- 메인 컴포넌트 ----
export default function StatsPage({
  selectedCup,
  showCommentBox = false,
  highlightCandidateId,
}) {
  const { t } = useTranslation();
  const [stats, setStats] = useState([]);
  const [sortKey, setSortKey] = useState("win_count");
  const [sortDesc, setSortDesc] = useState(true);
  const [search, setSearch] = useState("");
  const [userOnly, setUserOnly] = useState(false);
  const [itemsPerPage, setItemsPerPage] = useState(25);
  const [period, setPeriod] = useState(null);
  const [customMode, setCustomMode] = useState(false);
  const [customFrom, setCustomFrom] = useState("");
  const [customTo, setCustomTo] = useState("");
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 800);

  useEffect(() => {
    function onResize() {
      setIsMobile(window.innerWidth < 800);
    }
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  useEffect(() => {
    async function fetchStats() {
      if (!selectedCup?.id) {
        setStats([]);
        setLoading(false);
        return;
      }
      setLoading(true);
      if (customMode && customFrom && customTo) {
        const range = getCustomSinceDate(customFrom, customTo);
        const statsArr = await fetchWinnerStatsFromDB(selectedCup.id, range);
        setStats(statsArr);
        setLoading(false);
      } else {
        let since = getSinceDate(period);
        const statsArr = await fetchWinnerStatsFromDB(selectedCup.id, since);
        setStats(statsArr);
        setLoading(false);
      }
    }
    fetchStats();
  }, [selectedCup, period, customMode, customFrom, customTo]);

  let filteredStats = [...stats].filter(row => row.name?.toLowerCase().includes(search.toLowerCase()));
  if (userOnly) {
    filteredStats = filteredStats.map(row => ({
      ...row,
      win_count: row.user_win_count || 0,
    }));
  }

  // 정렬(각 칼럼 오름/내림차순, win_rate, match_win_rate 계산 포함)
  filteredStats = filteredStats
    .map((row, i) => ({ ...row, _originIdx: i }))
    .sort((a, b) => {
      let av = a[sortKey], bv = b[sortKey];
      if (sortKey === "win_rate")
        av = a.total_games ? a.win_count / a.total_games : 0,
        bv = b.total_games ? b.win_count / b.total_games : 0;
      if (sortKey === "match_win_rate")
        av = a.match_count ? a.match_wins / a.match_count : 0,
        bv = b.match_count ? b.match_wins / b.match_count : 0;
      if (typeof av === "string") av = av.toLowerCase();
      if (typeof bv === "string") bv = bv.toLowerCase();
      if (av < bv) return sortDesc ? 1 : -1;
      if (av > bv) return sortDesc ? -1 : 1;
      return a._originIdx - b._originIdx;
    });

  // 랭킹부여
  filteredStats.forEach((row, i) => { row.rank = i + 1; });
  const totalStats = filteredStats.length;
  const totalPages = Math.max(1, Math.ceil(totalStats / itemsPerPage));
  const pagedStats = filteredStats.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
  useEffect(() => { setCurrentPage(1); }, [search, itemsPerPage, stats]);

  // 카드 고정(우승 기준 1~3위)
  const top3 = [...stats]
    .sort((a, b) => (b.win_count ?? 0) - (a.win_count ?? 0))
    .slice(0, 3);

  // 표 스타일
  const ivoryCell = {
    background: "#fcf5cd",
    fontWeight: 800,
    color: "#998314",
    fontSize: isMobile ? 15 : 18,
    border: 0
  };

  const sortableCols = [
    { key: "rank", label: t("rank"), isIvory: true },
    { key: "image", label: t("image") },
    { key: "name", label: t("name") },
    { key: "win_count", label: t("win_count") },
    { key: "win_rate", label: t("win_rate"), isIvory: true },
    { key: "match_wins", label: t("match_wins") },
    { key: "match_count", label: t("duel_count") },
    { key: "match_win_rate", label: t("match_win_rate"), isIvory: true },
  ];

  // 페이지네이션
  function Pagination() {
    if (totalPages <= 1) return null;
    let pages = [];
    let start = Math.max(1, currentPage - 2);
    let end = Math.min(totalPages, currentPage + 2);
    for (let i = start; i <= end; i++) pages.push(i);

    if (start > 2) pages = [1, "...", ...pages];
    else if (start === 2) pages = [1, ...pages];
    if (end < totalPages - 1) pages = [...pages, "...", totalPages];
    else if (end === totalPages - 1) pages = [...pages, totalPages];

    return (
      <div style={{ textAlign: "center", margin: "16px 0 4px 0" }}>
        <button
          disabled={currentPage === 1}
          style={{
            margin: "0 4px",
            padding: "4px 10px",
            borderRadius: 6,
            border: "1.5px solid #bbb",
            background: currentPage === 1 ? "#f7f7f7" : "#fff",
            cursor: currentPage === 1 ? "default" : "pointer",
          }}
          onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
        >
          &lt;
        </button>
        {pages.map((p, i) =>
          p === "..." ? (
            <span key={i} style={{ margin: "0 4px" }}>...</span>
          ) : (
            <button
              key={p}
              onClick={() => setCurrentPage(p)}
              style={{
                margin: "0 4px",
                padding: "4px 12px",
                borderRadius: 6,
                border: "1.5px solid #1976ed",
                background: currentPage === p ? "#1976ed" : "#fff",
                color: currentPage === p ? "#fff" : "#1976ed",
                fontWeight: 700,
                cursor: "pointer",
              }}
            >
              {p}
            </button>
          )
        )}
        <button
          disabled={currentPage === totalPages}
          style={{
            margin: "0 4px",
            padding: "4px 10px",
            borderRadius: 6,
            border: "1.5px solid #bbb",
            background: currentPage === totalPages ? "#f7f7f7" : "#fff",
            cursor: currentPage === totalPages ? "default" : "pointer",
          }}
          onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
        >
          &gt;
        </button>
      </div>
    );
  }

  // 공유/신고
  function ShareAndReportBar() {
    if (!selectedCup?.id) return null;
    const shareUrl = `${window.location.origin}/select-round/${selectedCup.id}`;
    return (
      <div style={{
        display: "flex",
        justifyContent: "center",
        gap: 8,
        marginBottom: 18,
        marginTop: 0,
      }}>
        <ReportButton cupId={selectedCup.id} size="sm" />
        <button
          onClick={() => {
            navigator.clipboard.writeText(shareUrl);
            window?.toast?.success
              ? window.toast.success("월드컵 시작 링크가 복사되었습니다!")
              : alert("월드컵 시작 링크가 복사되었습니다!");
          }}
          style={{
            color: "#1976ed",
            background: "#e8f2fe",
            border: "1.2px solid #b8dafe",
            borderRadius: 8,
            padding: "4px 14px",
            fontWeight: 700,
            cursor: "pointer",
            fontSize: 15,
            minWidth: 60,
          }}
        >
          📢 월드컵 공유하기
        </button>
      </div>
    );
  }

  // ------ Render ------
  return (
    <div
      style={{
        width: "100%",
        maxWidth: 1200,
        margin: "0 auto",
        padding: "0 0 32px 0",
        boxSizing: "border-box",
      }}
    >
      {/* 상단 타이틀 */}
      <div style={{
        width: "100%",
        display: "flex",
        justifyContent: "center",
        margin: "34px 0 19px 0",
      }}>
        <div
          style={{
            fontWeight: 900,
            fontSize: isMobile ? 22 : 36,
            color: "#fff",
            background: "linear-gradient(135deg, #1947e5 22%, #0e1e36 92%)",
            boxShadow: "0 4px 24px 0 #1976ed26, 0 1px 12px #18317899, 0 0px 0px #111b2522",
            borderRadius: 18,
            padding: isMobile ? "11px 14px" : "22px 54px",
            border: "2px solid #1976ed66",
            textShadow: "0 2px 12px #1976ed44, 0 1px 8px #111b2599",
            fontFamily: "'Orbitron', 'Pretendard', sans-serif",
            letterSpacing: "-1.5px",
            lineHeight: 1.15,
            maxWidth: isMobile ? "96vw" : 700,
            minWidth: 0,
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "normal",
            display: "-webkit-box",
            WebkitBoxOrient: "vertical",
            WebkitLineClamp: 2,
            wordBreak: "break-all",
            textAlign: "center",
            margin: "0 auto",
            userSelect: "text",
          }}
          title={selectedCup.title}
        >
          {twoLineTitle(selectedCup.title)}
        </div>
      </div>
      <style>
        {`@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@700;900&display=swap');`}
      </style>
      <ShareAndReportBar />

      {/* 1~3등 카드형 */}
      <div style={{
        display: "flex",
        flexDirection: isMobile ? "column" : "row",
        justifyContent: "center",
        alignItems: "flex-end",
        margin: "0 auto 18px auto",
        width: "100%",
        gap: isMobile ? 0 : 0,
        overflowX: "auto"
      }}>
        {top3.map((row, i) =>
          row ? (
            <RankCard
              key={row.candidate_id}
              rank={i + 1}
              name={row.name}
              image={row.image}
              win_count={row.win_count}
              win_rate={row.total_games ? percent(row.win_count, row.total_games) : "-"}
              match_wins={row.match_wins}
              match_count={row.match_count}
              match_win_rate={row.match_count ? percent(row.match_wins, row.match_count) : "-"}
              isMobile={isMobile}
            />
          ) : null
        )}
      </div>

      {/* 전체/회원만 버튼 */}
      <div style={{
        display: "flex",
        justifyContent: "center",
        gap: 8,
        marginBottom: 10,
        marginTop: 4,
      }}>
        <button style={tabBtnStyle(!userOnly)} onClick={() => setUserOnly(false)}>전체</button>
        <button style={{ ...tabBtnStyle(userOnly), marginRight: 0 }} onClick={() => setUserOnly(true)}>회원만</button>
      </div>

      {/* 기간 버튼 */}
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: 0,
          justifyContent: "center",
          marginBottom: 10,
        }}
      >
        {PERIODS.map(p => (
          <button
            key={p.value === null ? "all" : p.value}
            onClick={() => {
              setCustomMode(false);
              setPeriod(p.value);
            }}
            style={periodBtnStyle(!customMode && period === p.value)}
          >
            {p.label}
          </button>
        ))}
        <button
          style={{
            ...periodBtnStyle(customMode),
            marginRight: 0,
            background: customMode ? "#e7f7f6" : "#fff",
          }}
          onClick={() => {
            setCustomMode(true);
            setPeriod(undefined);
          }}
        >
          기간설정
        </button>
        {customMode && (
          <>
            <input
              type="date"
              value={customFrom}
              max={customTo}
              onChange={e => setCustomFrom(e.target.value)}
              style={{ padding: "6px 11px", borderRadius: 8, border: "1.3px solid #bbb" }}
            />
            <span style={{ lineHeight: "33px", fontWeight: 700 }}>~</span>
            <input
              type="date"
              value={customTo}
              min={customFrom}
              onChange={e => setCustomTo(e.target.value)}
              style={{ padding: "6px 11px", borderRadius: 8, border: "1.3px solid #bbb" }}
            />
            <button
              style={{
                padding: "7px 13px",
                borderRadius: 8,
                border: "1.8px solid #1976ed",
                background: "#1976ed",
                color: "#fff",
                fontWeight: 700,
                fontSize: 15,
                cursor: "pointer",
                marginRight: 0,
              }}
              onClick={() => {
                if (customFrom && customTo) setCustomMode(true);
              }}
              disabled={!customFrom || !customTo}
            >
              적용
            </button>
            <button
              style={{
                padding: "7px 13px",
                borderRadius: 8,
                border: "1.5px solid #aaa",
                background: "#fff",
                color: "#666",
                fontWeight: 700,
                fontSize: 15,
                cursor: "pointer",
              }}
              onClick={() => {
                setCustomMode(false);
                setCustomFrom("");
                setCustomTo("");
                setPeriod(null);
              }}
            >
              취소
            </button>
          </>
        )}
      </div>

      {/* 페이지 개수 선택 */}
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          marginBottom: 8,
          gap: 8,
        }}
      >
        {[10, 25, 50, 100].map(num => (
          <button
            key={num}
            style={{
              padding: "7px 13px",
              borderRadius: 8,
              border: itemsPerPage === num ? "2.5px solid #1976ed" : "1.5px solid #ccc",
              background: itemsPerPage === num ? "#e8f2fe" : "#fff",
              color: itemsPerPage === num ? "#1976ed" : "#555",
              fontWeight: 700,
              fontSize: 15,
              cursor: "pointer",
            }}
            onClick={() => setItemsPerPage(num)}
          >
            {num}개씩 보기
          </button>
        ))}
      </div>

      {/* 검색창 */}
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          marginBottom: 16,
          marginTop: 0,
        }}
      >
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder={t("search")}
          style={{
            width: 180,
            padding: "9px 17px",
            borderRadius: 10,
            border: "1.5px solid #bbb",
            fontSize: 15,
          }}
        />
      </div>

      {/* --- 통계 테이블 --- */}
      <div style={{ width: "100%", overflowX: "auto", marginBottom: 12 }}>
        <table
          style={{
            width: "100%",
            borderCollapse: "collapse",
            background: "#fff",
            borderRadius: "12px",
            textAlign: "center",
            fontSize: isMobile ? 13 : 16,
            tableLayout: "fixed",
            wordBreak: "break-word",
            overflowWrap: "break-word",
            margin: "0 auto",
            boxShadow: "0 2px 22px #21374a13",
          }}
        >
          <thead>
            <tr>
              {sortableCols.map(col => (
                <th
                  key={col.key}
                  style={{
                    padding: "8px 0",
                    cursor: ["image"].includes(col.key) ? undefined : "pointer",
                    ...(col.isIvory ? ivoryCell : { background: "#fff", fontWeight: 700 }),
                    userSelect: "none"
                  }}
                  onClick={
                    ["image"].includes(col.key)
                      ? undefined
                      : () => {
                          if (sortKey === col.key) setSortDesc(desc => !desc);
                          else { setSortKey(col.key); setSortDesc(true); }
                        }
                  }
                >
                  <span>
                    {col.label}
                    {sortKey === col.key &&
                      (sortDesc ? " ▼" : " ▲")
                    }
                  </span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pagedStats.length === 0 && (
              <tr>
                <td colSpan={sortableCols.length} style={{ padding: 22, color: "#888" }}>
                  {t("cannotShowResult")}
                </td>
              </tr>
            )}
            {pagedStats.map((row, idx) => {
              const isHighlighted = highlightCandidateId && row.candidate_id === highlightCandidateId;
              const highlightStyle = isHighlighted
                ? {
                    background: "linear-gradient(90deg,#f9e7ff 0%,#f3fbff 80%)",
                    boxShadow: "0 2px 12px #d489ec15",
                    fontWeight: 800,
                    borderLeft: "6px solid #d489ec",
                    color: "#7114b5",
                    fontSize: isMobile ? 15 : 17,
                    transition: "all 0.12s"
                  }
                : { background: (idx % 2 === 0) ? "#fafdff" : "#fff" };
              return (
                <tr key={row.candidate_id} style={highlightStyle}>
                  {/* rank */}
                  <td style={ivoryCell}>{row.rank}</td>
                  {/* image */}
                  <td style={{
                    padding: "7px 0",
                    background: "#fff"
                  }}>
                    <div
                      style={{
                        width: isMobile ? 30 : 38,
                        height: isMobile ? 30 : 38,
                        borderRadius: 7,
                        overflow: "hidden",
                        margin: "0 auto",
                        background: "#f8f9fa",
                        border: "1.5px solid #e7f1fb"
                      }}
                    >
                      <MediaRenderer url={row.image} alt={row.name} />
                    </div>
                  </td>
                  {/* 이름 */}
                  <td style={{
                    padding: "7px 0",
                    background: "#fff",
                    fontWeight: 700,
                    fontSize: isMobile ? 13 : 15,
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                    maxWidth: isMobile ? 90 : 120,
                  }}>
                    {row.name}
                  </td>
                  {/* win_count */}
                  <td style={{ padding: "7px 0", background: "#fff" }}>{row.win_count}</td>
                  {/* win_rate */}
                  <td style={ivoryCell}>
                    {row.total_games ? percent(row.win_count, row.total_games) : "-"}
                  </td>
                  {/* match_wins */}
                  <td style={{ padding: "7px 0", background: "#fff" }}>{row.match_wins}</td>
                  {/* duel_count */}
                  <td style={{ padding: "7px 0", background: "#fff" }}>{row.match_count}</td>
                  {/* match_win_rate */}
                  <td style={ivoryCell}>
                    {row.match_count ? percent(row.match_wins, row.match_count) : "-"}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <Pagination />
      {showCommentBox && <CommentBox cupId={selectedCup.id} />}
    </div>
  );
}

// 탭버튼 스타일
function tabBtnStyle(selected) {
  return {
    padding: "8px 19px",
    marginRight: 8,
    borderRadius: 8,
    border: selected
      ? "2.5px solid #1976ed"
      : "1.5px solid #ccc",
    background: selected ? "#e8f2fe" : "#fff",
    color: selected ? "#1976ed" : "#555",
    fontWeight: 700,
    fontSize: 15,
    cursor: "pointer",
    transition: "all 0.15s",
    boxShadow: selected ? "0 2px 7px #1976ed22" : undefined,
    marginBottom: 7,
  };
}
// 기간버튼 스타일
function periodBtnStyle(selected) {
  return {
    padding: "7px 15px",
    marginRight: 7,
    marginBottom: 6,
    borderRadius: 8,
    border: selected
      ? "2.5px solid #1976ed"
      : "1.5px solid #ccc",
    background: selected ? "#e8f2fe" : "#fff",
    color: selected ? "#1976ed" : "#555",
    fontWeight: 700,
    fontSize: 15,
    cursor: "pointer",
    transition: "all 0.15s"
  };
}
