import React, { useState, useEffect } from "react";
import { fetchWinnerStatsFromDB } from "../utils";
import { useTranslation } from "react-i18next";
import MediaRenderer from "./MediaRenderer";

function percent(n, d) {
  if (!d) return "-";
  return Math.round((n / d) * 100) + "%";
}

// 기간 필터 세팅 (일 단위)
const PERIODS = [
  { label: "1주일", value: 7 },
  { label: "1개월", value: 30 },
  { label: "3개월", value: 90 },
  { label: "6개월", value: 180 },
  { label: "1년", value: 365 },
  { label: "전체", value: null }
];
function getSinceDate(days) {
  if (!days) return null;
  const date = new Date();
  date.setDate(date.getDate() - days);
  return date.toISOString();
}

function StatsPage({ selectedCup }) {
  const { t } = useTranslation();
  const [stats, setStats] = useState([]);
  const [sortKey, setSortKey] = useState("win_count");
  const [sortDesc, setSortDesc] = useState(true);
  const [search, setSearch] = useState("");
  const [isMobile, setIsMobile] = useState(window.innerWidth < 800);
  const [userOnly, setUserOnly] = useState(false);

  // 기간 관련 state
  const [period, setPeriod] = useState(7); // 기본 1주일

  useEffect(() => {
    async function fetchStats() {
      if (!selectedCup?.id) return setStats([]);
      // 기간 조건
      let since = getSinceDate(period);
      // fetchWinnerStatsFromDB에서 since(ISO) 값을 넘기면,
      // winner_stats에서 created_at >= since 조건으로 데이터 추출
      const statsArr = await fetchWinnerStatsFromDB(selectedCup.id, since);
      setStats(statsArr);
    }
    fetchStats();
  }, [selectedCup, period]);

  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 800);
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  // 필터링 & 정렬
  let filteredStats = [...stats]
    .filter(row => row.name?.toLowerCase().includes(search.toLowerCase()));

  // *** 수정: filter가 아니라 map으로 교체 ***
  if (userOnly) {
    filteredStats = filteredStats.map(row => ({
      ...row,
      win_count: row.user_win_count || 0,
      // win_rate, match_wins 등도 user만 기준으로 바꾸려면 아래처럼 추가 (선택)
      // match_wins: row.user_match_wins || 0,
      // match_count: row.user_match_count ?? row.match_count,
    }));
    // filter(row => row.user_win_count > 0) 절대 쓰지마세요!
  }

  filteredStats = filteredStats.sort((a, b) =>
    sortDesc
      ? (b[sortKey] ?? 0) - (a[sortKey] ?? 0)
      : (a[sortKey] ?? 0) - (b[sortKey] ?? 0)
  );

  function getRowStyle(rank) {
    if (rank === 1) return { background: "#fff9dd" };
    if (rank === 2) return { background: "#e9f3ff" };
    if (rank === 3) return { background: "#ffe9ea" };
    return {};
  }
  function getNameTextStyle(rank) {
    if (rank === 1) return { color: "#e0af19", fontWeight: 700 };
    if (rank === 2) return { color: "#4286f4", fontWeight: 700 };
    if (rank === 3) return { color: "#e26464", fontWeight: 700 };
    return {};
  }

  const nameTdStyle = {
    maxWidth: isMobile ? 90 : 120,
    wordBreak: "break-word",
    overflow: "hidden",
    textOverflow: "ellipsis",
    display: "-webkit-box",
    WebkitLineClamp: 2,
    WebkitBoxOrient: "vertical",
    whiteSpace: "normal",
    fontWeight: 700,
    fontSize: isMobile ? 13 : 15,
    lineHeight: 1.18,
    textAlign: "left",
    verticalAlign: "middle"
  };

  // 스타일 구분 함수
  function tabBtnStyle(selected) {
    return {
      padding: "8px 19px",
      marginRight: 8,
      borderRadius: 8,
      border: selected
        ? "2.5px solid #1976ed"
        : "1.5px solid #ccc",
      background: selected ? "#e8f2fe" : "#fff",
      color: selected ? "#1976ed" : "#555",
      fontWeight: 700,
      fontSize: 15,
      cursor: "pointer",
      transition: "all 0.15s",
      boxShadow: selected ? "0 2px 7px #1976ed22" : undefined
    };
  }

  // 기간 버튼 스타일
  function periodBtnStyle(selected) {
    return {
      padding: "7px 15px",
      marginRight: 7,
      marginBottom: 6,
      borderRadius: 8,
      border: selected
        ? "2.5px solid #1976ed"
        : "1.5px solid #ccc",
      background: selected ? "#e8f2fe" : "#fff",
      color: selected ? "#1976ed" : "#555",
      fontWeight: 700,
      fontSize: 15,
      cursor: "pointer",
      transition: "all 0.15s"
    };
  }

  return (
    <div
      style={{
        width: "100%",
        maxWidth: 1200,
        margin: "0 auto",
        padding: isMobile ? "0 0 24px 0" : "0 0 32px 0",
        boxSizing: "border-box"
      }}
    >
      {/* 기간별 필터 버튼 */}
      <div style={{ marginBottom: 16, display: "flex", alignItems: "center", flexWrap: "wrap" }}>
        {PERIODS.map((p) => (
          <button
            key={p.value ?? "all"}
            onClick={() => setPeriod(p.value)}
            style={periodBtnStyle(period === p.value)}
          >
            {p.label}
          </button>
        ))}
        <div style={{ width: 18 }} /> {/* 간격 */}
        <button
          style={tabBtnStyle(!userOnly)}
          onClick={() => setUserOnly(false)}
        >
          전체
        </button>
        <button
          style={{ ...tabBtnStyle(userOnly), marginRight: 0 }}
          onClick={() => setUserOnly(true)}
        >
          회원만
        </button>
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder={t("search")}
          style={{
            marginLeft: 18,
            width: 140,
            padding: "7px 13px",
            borderRadius: 8,
            border: "1.5px solid #bbb",
            fontSize: 14
          }}
        />
      </div>
      <div style={{ width: "100%", overflowX: "auto" }}>
        <table
          style={{
            width: "100%",
            borderCollapse: "collapse",
            background: "#fff",
            borderRadius: "12px",
            textAlign: "center",
            fontSize: isMobile ? 13 : 17,
            tableLayout: "fixed",
            wordBreak: "break-word",
            overflowWrap: "break-word",
          }}
        >
          <thead>
            <tr style={{ background: "#f7f7f7" }}>
              <th style={{ padding: "10px 0" }}>{t("rank")}</th>
              <th style={{ padding: "10px 0" }}>{t("image")}</th>
              <th style={{ padding: "10px 0" }}>{t("name")}</th>
              <th
                style={{ padding: "10px 0", cursor: "pointer" }}
                onClick={() => {
                  setSortKey("win_count");
                  setSortDesc(k => !k);
                }}
              >
                {t("win_count")} {sortKey === "win_count" ? (sortDesc ? "▼" : "▲") : ""}
              </th>
              <th style={{ padding: "10px 0" }}>{t("win_rate")}</th>
              <th
                style={{ padding: "10px 0", cursor: "pointer" }}
                onClick={() => {
                  setSortKey("match_wins");
                  setSortDesc(k => !k);
                }}
              >
                {t("match_wins")} {sortKey === "match_wins" ? (sortDesc ? "▼" : "▲") : ""}
              </th>
              <th
                style={{ padding: "10px 0", cursor: "pointer" }}
                onClick={() => {
                  setSortKey("match_count");
                  setSortDesc(k => !k);
                }}
              >
                {t("duel_count")} {sortKey === "match_count" ? (sortDesc ? "▼" : "▲") : ""}
              </th>
              <th style={{ padding: "10px 0" }}>{t("match_win_rate")}</th>
            </tr>
          </thead>
          <tbody>
            {filteredStats.map((row, i) => (
              <tr
                key={row.candidate_id}
                style={{
                  ...getRowStyle(i + 1),
                  textAlign: "center",
                  fontWeight: i + 1 <= 3 ? 700 : 400
                }}
              >
                <td
                  style={{
                    padding: "7px 0",
                    fontSize: isMobile ? 15 : 19,
                    ...getNameTextStyle(i + 1)
                  }}
                >
                  {i + 1 <= 3 ? (
                    <span>
                      <span style={{ fontSize: 18, verticalAlign: "middle" }}>👑</span>{" "}
                      {i + 1}
                    </span>
                  ) : i + 1}
                </td>
                <td style={{ padding: "7px 0" }}>
                  <div style={{
                    width: isMobile ? 30 : 44,
                    height: isMobile ? 30 : 44,
                    borderRadius: 9,
                    overflow: "hidden",
                    margin: "0 auto"
                  }}>
                    <MediaRenderer url={row.image} alt={row.name} />
                  </div>
                </td>
                <td
                  style={{
                    padding: "7px 0",
                    ...getNameTextStyle(i + 1),
                    ...nameTdStyle,
                  }}
                >
                  {row.name}
                </td>
                <td style={{ padding: "7px 0", ...getNameTextStyle(i + 1) }}>
                  {row.win_count}
                </td>
                <td style={{ padding: "7px 0", ...getNameTextStyle(i + 1) }}>
                  {row.total_games ? percent(row.win_count, row.total_games) : "-"}
                </td>
                <td style={{ padding: "7px 0" }}>{row.match_wins}</td>
                <td style={{ padding: "7px 0" }}>{row.match_count}</td>
                <td style={{ padding: "7px 0" }}>
                  {row.match_count ? percent(row.match_wins, row.match_count) : "-"}
                </td>
              </tr>
            ))}
            {filteredStats.length === 0 && (
              <tr>
                <td colSpan={8} style={{ padding: 24, color: "#888" }}>
                  {t("cannotShowResult")}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default StatsPage;
