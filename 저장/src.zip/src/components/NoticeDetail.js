import React, { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { supabase } from "../utils/supabaseClient";

export default function NoticeDetail() {
  const { id, lang = "en" } = useParams();
  const navigate = useNavigate();
  const [notice, setNotice] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchNotice() {
      setLoading(true);
      const { data } = await supabase
        .from("notice")
        .select("*")
        .eq("id", id)
        .single();
      setNotice(data);
      setLoading(false);
    }
    fetchNotice();
  }, [id]);

  if (loading) return (
    <div style={{ maxWidth: 700, margin: "80px auto", color: "#222" }}>
      <h2>Loading...</h2>
    </div>
  );

  if (!notice) return (
    <div style={{ maxWidth: 700, margin: "80px auto", color: "#222" }}>
      <h2>Notice not found</h2>
      <button onClick={() => navigate(-1)}>Back</button>
    </div>
  );

  return (
    <div style={{
      maxWidth: 700, margin: "60px auto",
      background: "#f7fbff", borderRadius: 16, boxShadow: "0 2px 16px #1976ed22",
      color: "#1c2335", padding: 38,
    }}>
      <h2 style={{
        color: "#1976ed", fontWeight: 900, fontSize: 26, marginBottom: 16
      }}>{notice.title}</h2>
      <div style={{ color: "#888", marginBottom: 14, fontSize: 14 }}>
        {new Date(notice.created_at).toLocaleString()}
      </div>
      <div style={{ fontSize: 18, marginTop: 18, lineHeight: 1.88, whiteSpace: "pre-line" }}>
        {notice.content}
      </div>
      <Link
        to={`/${lang}/notice`}
        style={{
          color: "#3faaff",
          textDecoration: "underline",
          fontSize: 15,
          marginTop: 28,
          display: "inline-block"
        }}
      >
        ← Back to Notices
      </Link>
    </div>
  );
}
