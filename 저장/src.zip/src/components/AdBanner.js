// src/components/AdBanner.js
import React from 'react';

const AdBanner = ({ position, img, width = 300, height = 250, style }) => {
  let posStyle = {};
  let bannerStyle = {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'fixed',
    zIndex: 99,
    ...style,
  };

  switch (position) {
    case 'top':
      posStyle = { top: 90, left: '50%', transform: 'translateX(-50%)' };
      break;
    case 'bottom':
      posStyle = { bottom: 20, left: '50%', transform: 'translateX(-50%)' };
      break;
    case 'left':
      posStyle = { top: '50%', left: 30, transform: 'translateY(-50%)' };
      break;
    case 'right':
      posStyle = { top: '50%', right: 30, transform: 'translateY(-50%)' };
      break;
    default:
      break;
  }

  return (
    <div
      className={`ad-banner ${position}`}
      style={{ ...bannerStyle, ...posStyle, width, height }}
    >
      <img
        src={img}
        alt="banner"
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          borderRadius: 13,
          boxShadow: '0 2px 18px #0002',
        }}
      />
    </div>
  );
};

export default AdBanner;
