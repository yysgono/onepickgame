const items = [
  {
    id: 1,
    name: "Pizza",
    type: "image",
    image: "https://images.unsplash.com/photo-1542281286-9e0a16bb7366"
  },
  {
    id: 2,
    name: "Funny Cat Video",
    type: "youtube",
    youtubeId: "J---aiyznGQ"
  },
  {
    id: 3,
    name: "Burger",
    type: "image",
    image: "https://images.unsplash.com/photo-1550547660-d9450f859349"
  },
  {
    id: 4,
    name: "Epic Dog",
    type: "youtube",
    youtubeId: "tntOCGkgt98"
  }
];

export default items;
