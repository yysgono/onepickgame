import React, { useEffect } from "react";
import { Helmet } from "react-helmet";
import Home from "../../components/Home";
import { useTranslation } from "react-i18next";

export default function PtPage(props) {
  const { i18n } = useTranslation();

  useEffect(() => {
    if (i18n.language !== "pt") {
      i18n.changeLanguage("pt");
      localStorage.setItem("onepickgame_lang", "pt");
    }
  }, [i18n]);

  const base = "https://www.onepickgame.com";
  const self = `${base}/pt`;

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: "One Pick Game",
    alternateName: ["OnePickGame", "Copa do Mundo do Tipo Ideal"],
    url: base,
    inLanguage: "pt",
    potentialAction: {
      "@type": "SearchAction",
      target: `${base}/pt?search={query}`,
      "query-input": "required name=query",
    },
  };

  return (
    <>
      <Helmet htmlAttributes={{ lang: "pt" }}>
        <title>One Pick Game - Copa do Mundo do Tipo Ideal Torneio</title>
        <meta
          name="description"
          content="Jogue a Copa do Mundo do Tipo Ideal no One Pick Game! Crie seus próprios torneios, vote em seus favoritos e divirta-se com usuários de todo o mundo."
        />

        {/* Canonical & OpenGraph */}
        <link rel="canonical" href={self} />
<meta property="og:title" content="Torneio de Votação - One Pick Game" />
        <meta
          property="og:description"
          content="One Pick Game é o site da Copa do Mundo do Tipo Ideal. Crie seu próprio torneio, vote e compartilhe os resultados com amigos em todo o mundo!"
        />
        <meta property="og:image" content={`${base}/ogimg.png`} />
        <meta property="og:url" content={self} />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="One Pick Game" />
        <meta property="og:locale" content="pt_BR" />

        {/* Twitter Card */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta
          name="twitter:title"
          content="One Pick Game - Copa do Mundo do Tipo Ideal Torneio"
        />
        <meta
          name="twitter:description"
          content="One Pick Game é o site da Copa do Mundo do Tipo Ideal. Crie seu próprio torneio, vote e compartilhe os resultados com amigos em todo o mundo!"
        />
        <meta name="twitter:image" content={`${base}/ogimg.png`} />

        {/* hreflang */}
        <link rel="alternate" hrefLang="ar" href={`${base}/ar`} />
        <link rel="alternate" hrefLang="bn" href={`${base}/bn`} />
        <link rel="alternate" hrefLang="de" href={`${base}/de`} />
        <link rel="alternate" hrefLang="en" href={`${base}/en`} />
        <link rel="alternate" hrefLang="es" href={`${base}/es`} />
        <link rel="alternate" hrefLang="fr" href={`${base}/fr`} />
        <link rel="alternate" hrefLang="hi" href={`${base}/hi`} />
        <link rel="alternate" hrefLang="id" href={`${base}/id`} />
        <link rel="alternate" hrefLang="ja" href={`${base}/ja`} />
        <link rel="alternate" hrefLang="ko" href={`${base}/ko`} />
        <link rel="alternate" hrefLang="pt" href={`${base}/pt`} />
        <link rel="alternate" hrefLang="ru" href={`${base}/ru`} />
        <link rel="alternate" hrefLang="th" href={`${base}/th`} />
        <link rel="alternate" hrefLang="tr" href={`${base}/tr`} />
        <link rel="alternate" hrefLang="vi" href={`${base}/vi`} />
        <link rel="alternate" hrefLang="zh" href={`${base}/zh`} />
        <link rel="alternate" hrefLang="x-default" href={`${base}/en`} />

        {/* JSON-LD */}
        <script type="application/ld+json">{JSON.stringify(jsonLd)}</script>
      </Helmet>

      <Home {...props} />
    </>
  );
}
