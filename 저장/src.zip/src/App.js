// src/App.js
import "./i18n";
import "./App.css";
import React, { useState, useEffect, useRef } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useNavigate,
  useParams,
  useLocation,
} from "react-router-dom";
import { useTranslation } from "react-i18next";

import Header from "./components/Header";
import Home from "./components/Home";
import SelectRoundPage from "./components/SelectRoundPage";
import MatchPage from "./components/MatchPage";
import ResultPage from "./components/ResultPage";
import StatsPage from "./components/StatsPage";
import WorldcupMaker from "./components/WorldcupMaker";
import BackupPage from "./components/BackupPage";
import ManageWorldcup from "./components/ManageWorldcup";
import EditWorldcupPage from "./components/EditWorldcupPage";
import AdminBar from "./components/AdminBar";
import AdminDashboard from "./components/AdminDashboard";
import AdminStatsPage from "./components/AdminStatsPage";
import SignupBox from "./components/SignupBox";
import LoginBox from "./components/LoginBox";
import FindIdBox from "./components/FindIdBox";
import FindPwBox from "./components/FindPwBox";
import PrivacyPolicy from "./components/PrivacyPolicy";
import TermsOfService from "./components/TermsOfService";
import Footer from "./components/Footer";
// AdBanner 컴포넌트 삭제 시 import도 삭제하세요
// import AdBanner from "./components/AdBanner";

import DePage from "./pages/de/index";
import EnPage from "./pages/en/index";
import EsPage from "./pages/es/index";
import FrPage from "./pages/fr/index";
import HiPage from "./pages/hi/index";
import IdPage from "./pages/id/index";
import JaPage from "./pages/ja/index";
import KoPage from "./pages/ko/index";
import PtPage from "./pages/pt/index";
import RuPage from "./pages/ru/index";
import ViPage from "./pages/vi/index";
import ZhPage from "./pages/zh/index";

import { getWorldcupGames, deleteWorldcupGame } from "./utils/supabaseWorldcupApi";
import { supabase } from "./utils/supabaseClient";

function useIsMobile() {
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 700);
  useEffect(() => {
    function onResize() {
      setIsMobile(window.innerWidth <= 700);
    }
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);
  return isMobile;
}

function ResetPwRedirect() {
  const navigate = useNavigate();
  useEffect(() => {
    navigate("/");
  }, [navigate]);
  return null;
}

function LanguageWrapper(props) {
  const { lang } = useParams();
  const { i18n } = useTranslation();
  const navigate = useNavigate();

  useEffect(() => {
    const supportedLangs = [
      "ko", "en", "ru", "ja", "zh", "pt", "es", "fr", "id", "hi", "de", "vi"
    ];
    if (!supportedLangs.includes(lang)) {
      navigate("/", { replace: true });
      return;
    }
    if (i18n.language !== lang) {
      i18n.changeLanguage(lang);
    }
  }, [lang, i18n, navigate]);

  switch (lang) {
    case "ko": return <KoPage {...props} />;
    case "en": return <EnPage {...props} />;
    case "ru": return <RuPage {...props} />;
    case "ja": return <JaPage {...props} />;
    case "zh": return <ZhPage {...props} />;
    case "pt": return <PtPage {...props} />;
    case "es": return <EsPage {...props} />;
    case "fr": return <FrPage {...props} />;
    case "id": return <IdPage {...props} />;
    case "hi": return <HiPage {...props} />;
    case "de": return <DePage {...props} />;
    case "vi": return <ViPage {...props} />;
    default: return <Home {...props} />;
  }
}

function App() {
  const isMobile = useIsMobile();

  const [worldcupList, setWorldcupList] = useState([]);
  const { t, i18n } = useTranslation();
  const [user, setUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [nickname, setNickname] = useState("");
  const [nicknameLoading, setNicknameLoading] = useState(false);

  const [fixedWorldcupIds, setFixedWorldcupIds] = useState([]);
  const [fixedWorldcups, setFixedWorldcups] = useState([]);

  useEffect(() => {
    let isMounted = true;
    async function fetchUserAndProfile() {
      setNicknameLoading(true);
      const { data } = await supabase.auth.getUser();
      if (isMounted) setUser(data?.user || null);
      if (data?.user) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("nickname")
          .eq("id", data.user.id)
          .single();
        if (isMounted) {
          setNickname(profile?.nickname || "");
          setIsAdmin(profile?.nickname === "admin");
        }
      } else {
        setNickname("");
        setIsAdmin(false);
      }
      setNicknameLoading(false);
    }
    fetchUserAndProfile();
    return () => { isMounted = false; };
  }, []);

  function updateNickname(nick) {
    setNickname(nick);
    setIsAdmin(nick === "admin");
  }

  const fetchWorldcups = async () => {
    try {
      const list = await getWorldcupGames();
      setWorldcupList(list);
    } catch {
      setWorldcupList([]);
    }
  };

  useEffect(() => {
    fetchWorldcups();
  }, []);

  useEffect(() => {
    async function fetchFixedWorldcups() {
      let { data, error } = await supabase
        .from("fixed_worldcups")
        .select("worldcup_id")
        .order("id", { ascending: true });
      if (!error && Array.isArray(data)) {
        setFixedWorldcupIds(data.map((d) => String(d.worldcup_id)));
      } else {
        setFixedWorldcupIds([]);
      }
    }
    fetchFixedWorldcups();
  }, []);

  useEffect(() => {
    if (!worldcupList.length || !fixedWorldcupIds.length) {
      setFixedWorldcups([]);
      return;
    }
    const fixeds = fixedWorldcupIds
      .map((id) => worldcupList.find((cup) => String(cup.id) === String(id)))
      .filter(Boolean);
    setFixedWorldcups(fixeds);
  }, [worldcupList, fixedWorldcupIds]);

  useEffect(() => {
    const savedLang = localStorage.getItem("onepickgame_lang");
    if (savedLang && savedLang !== i18n.language) {
      i18n.changeLanguage(savedLang);
    }
  }, [i18n]);

  function handleLangChange(lng) {
    i18n.changeLanguage(lng);
    localStorage.setItem("onepickgame_lang", lng);
  }

  function handleBackup() {
    const data = JSON.stringify(worldcupList || []);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `worldcup_backup_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function handleRestore(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function (ev) {
      try {
        const data = JSON.parse(ev.target.result);
        if (!Array.isArray(data)) throw new Error("Invalid format");
        setWorldcupList(data);
        alert(t("restore_success") || "Restore successful! (Front-end only, DB not affected)");
      } catch {
        alert(t("restore_fail") || "Restore failed!");
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  }

  function MyWorldcupsWrapper() {
    const myId = user?.id;
    const myList = worldcupList.filter(
      (w) => w.owner === myId || w.creator === myId || w.creator_id === myId
    );
    return (
      <Home
        worldcupList={myList}
        fetchWorldcups={fetchWorldcups}
        onSelect={(cup) => (window.location.href = `/select-round/${cup.id}`)}
        user={user}
        nickname={nickname}
        isAdmin={isAdmin}
        showFixedWorldcups={false}
      />
    );
  }

  function RecentWorldcupsWrapper() {
    let recents = [];
    try {
      recents = JSON.parse(localStorage.getItem("onepickgame_recentWorldcups") || "[]");
    } catch {}
    recents = recents
      .reverse()
      .filter((id, i, arr) => arr.indexOf(id) === i);
    const recentCups = recents
      .map((id) => worldcupList.find((w) => String(w.id) === String(id)))
      .filter(Boolean);
    return (
      <Home
        worldcupList={recentCups}
        fetchWorldcups={fetchWorldcups}
        onSelect={(cup) => (window.location.href = `/select-round/${cup.id}`)}
        user={user}
        nickname={nickname}
        isAdmin={isAdmin}
        showFixedWorldcups={false}
      />
    );
  }

  function AppRoutes() {
    const navigate = useNavigate();

    function handleMakeWorldcup() {
      if (!user) {
        alert(t("login_required") || "Login required.");
        return;
      }
      navigate("/worldcup-maker");
    }

    function HomeWrapper() {
      const navigate = useNavigate();
      return (
        <Home
          worldcupList={worldcupList}
          fetchWorldcups={fetchWorldcups}
          onSelect={(cup) => {
            let recent = [];
            try {
              recent = JSON.parse(localStorage.getItem("onepickgame_recentWorldcups") || "[]");
            } catch {}
            localStorage.setItem(
              "onepickgame_recentWorldcups",
              JSON.stringify([cup.id, ...recent.filter((id) => id !== cup.id)].slice(0, 30))
            );
            navigate(`/select-round/${cup.id}`);
          }}
          onMakeWorldcup={handleMakeWorldcup}
          onDelete={async (id) => {
            try {
              await deleteWorldcupGame(id);
              setWorldcupList((list) => list.filter((cup) => cup.id !== id));
            } catch (e) {
              alert((t("delete_failed") || "Delete failed!") + " " + (e.message || e));
            }
          }}
          user={user}
          nickname={nickname}
          isAdmin={isAdmin}
          fixedWorldcups={fixedWorldcups}
        />
      );
    }

    function SelectRoundPageWrapper() {
      const { id } = useParams();
      const navigate = useNavigate();
      const cup = worldcupList.find((c) => String(c.id) === id);
      if (!cup) return null;
      return (
        <SelectRoundPage
          cup={cup}
          maxRound={cup.data.length}
          candidates={cup.data}
          onSelect={(round) => navigate(`/match/${id}/${round}`)}
        />
      );
    }

    function StatsPageWrapper() {
      const { id } = useParams();
      const cup = worldcupList.find((c) => String(c.id) === id);
      if (!cup) return null;
      return <StatsPage selectedCup={cup} showCommentBox={true} />;
    }

    function WorldcupMakerWrapper() {
      const navigate = useNavigate();
      return (
        <WorldcupMaker
          fetchWorldcups={fetchWorldcups}
          onCreate={() => {
            window.location.href = "/";
          }}
          onCancel={() => navigate("/")}
          user={user}
          nickname={nickname}
        />
      );
    }

    function ManageWorldcupWrapper() {
      return (
        <ManageWorldcup
          user={user}
          isAdmin={isAdmin}
          worldcupList={worldcupList}
          setWorldcupList={setWorldcupList}
        />
      );
    }

    function EditWorldcupPageWrapper() {
      const { id } = useParams();
      return (
        <EditWorldcupPage
          worldcupList={worldcupList}
          fetchWorldcups={fetchWorldcups}
          cupId={id}
          user={user}
          nickname={nickname}
        />
      );
    }

    function AdminRoute() {
      if (!isAdmin) {
        return (
          <div
            style={{
              padding: 60,
              textAlign: "center",
              fontWeight: 700,
              fontSize: 22,
            }}
          >
            {t("admin_only") || "Admins only."}
            <br />
            {t("login_with_admin") || "Please log in as admin."}
          </div>
        );
      }
      return (
        <>
          <AdminBar
            onLogout={() => {
              supabase.auth.signOut().then(() => window.location.reload());
            }}
          />
          <AdminDashboard />
        </>
      );
    }

    function AdminStatsRoute() {
      if (!isAdmin) {
        return (
          <div
            style={{
              padding: 60,
              textAlign: "center",
              fontWeight: 700,
              fontSize: 22,
            }}
          >
            {t("admin_only") || "Admins only."}
            <br />
            {t("login_with_admin") || "Please log in as admin."}
          </div>
        );
      }
      return (
        <>
          <AdminBar
            onLogout={() => {
              supabase.auth.signOut().then(() => window.location.reload());
            }}
          />
          <AdminStatsPage />
        </>
      );
    }

    return (
      <>
        <div className="header-wrapper" style={{ margin: 0, padding: 0 }}>
          <Header
            onLangChange={handleLangChange}
            onBackup={handleBackup}
            onRestore={handleRestore}
            onMakeWorldcup={handleMakeWorldcup}
            isAdmin={isAdmin}
            user={user}
            nickname={nickname}
            nicknameLoading={nicknameLoading}
            setUser={setUser}
            setNickname={updateNickname}
          />
        </div>
        {/* AdBanner 관련 코드 삭제 시 이 부분 제거 또는 주석 처리 */}
        {/* <div className="ad-banner-top-static-wrap" style={{ marginTop: 0, paddingTop: 0 }}>
          <AdBanner position="top" img="ad2.png" />
        </div> */}
        <div className="main-content-box">
          <Routes>
            {/* 언어 경로 별 페이지 렌더링 */}
            <Route
              path="/:lang"
              element={
                <LanguageWrapper
                  worldcupList={worldcupList}
                  fetchWorldcups={fetchWorldcups}
                  user={user}
                  nickname={nickname}
                  isAdmin={isAdmin}
                  fixedWorldcups={fixedWorldcups}
                />
              }
            />

            <Route path="/" element={<HomeWrapper />} />
            <Route path="/my-worldcups" element={<MyWorldcupsWrapper />} />
            <Route path="/recent-worldcups" element={<RecentWorldcupsWrapper />} />
            <Route path="/select-round/:id" element={<SelectRoundPageWrapper />} />
            <Route path="/match/:id/:round" element={<MatchPage worldcupList={worldcupList} />} />
            <Route path="/result/:id" element={<ResultPage worldcupList={worldcupList} />} />
            <Route path="/result/:id/:round" element={<ResultPage worldcupList={worldcupList} />} />
            <Route path="/stats/:id" element={<StatsPageWrapper />} />
            <Route path="/worldcup-maker" element={<WorldcupMakerWrapper />} />
            <Route path="/manage" element={<ManageWorldcupWrapper />} />
            <Route path="/backup" element={<BackupPage worldcupList={worldcupList} setWorldcupList={setWorldcupList} />} />
            <Route path="/edit-worldcup/:id" element={<EditWorldcupPageWrapper />} />
            <Route path="/admin" element={<AdminRoute />} />
            <Route path="/admin-stats" element={<AdminStatsRoute />} />
            <Route path="/signup" element={<SignupBox />} />
            <Route path="/login" element={<LoginBox setUser={setUser} setNickname={updateNickname} />} />
            <Route path="/find-id" element={<FindIdBox />} />
            <Route path="/find-pw" element={<FindPwBox />} />
            <Route path="/reset-password" element={<ResetPwRedirect />} />
            <Route path="/privacy-policy" element={<PrivacyPolicy />} />
            <Route path="/terms-of-service" element={<TermsOfService />} />
          </Routes>
        </div>
      </>
    );
  }

  return (
    <div
      className="app-main-wrapper"
      style={{
        margin: 0,
        padding: 0,
        minHeight: "100vh",
        position: "relative",
      }}
    >
      <div
        style={{
          position: "fixed",
          inset: 0,
          width: "100vw",
          height: "100vh",
          zIndex: 0,
          pointerEvents: "none",
          background: `url("/onepick.png") center center / cover no-repeat fixed`,
        }}
      />
      <div
        style={{
          position: "fixed",
          inset: 0,
          width: "100vw",
          height: "100vh",
          zIndex: 1,
          pointerEvents: "none",
          background: "rgba(0,0,0,0.0)",
        }}
      />
      <div style={{ position: "relative", zIndex: 2 }}>
        {/* AdBanner 좌우 배너 제거 시 이 부분도 주석/삭제하세요 */}
        {/* <AdBanner
          position="left"
          img="ad1.png"
          style={{
            top: "50%",
            left: 24,
            transform: "translateY(-50%)",
            maxHeight: "95vh",
            width: "300px",
          }}
        />
        <AdBanner
          position="right"
          img="ad1.png"
          style={{
            top: "50%",
            right: 24,
            transform: "translateY(-50%)",
            maxHeight: "95vh",
            width: "300px",
          }}
        /> */}
        <div
          className="main-content-outer"
          style={{ paddingTop: 190, margin: 0 }}
        >
          <Router>
            <AppRoutes />
            {/* Footer 항상 보임 */}
            <Footer />
          </Router>
        </div>
      </div>
    </div>
  );
}

export default App;
