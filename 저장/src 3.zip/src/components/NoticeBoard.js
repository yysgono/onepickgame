import React from "react";

// ✅ Notice & Recent Comments 완전 제거 버전
// 화면 어디에서도 Notice 영역이 표시되지 않습니다.
export default function NoticeBoard() {
  return null; // 아무 것도 렌더링하지 않음
}
